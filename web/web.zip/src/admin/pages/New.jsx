import React, { Component } from 'react';

export default class New extends Component {
  render() {
    return (
      <div>
        <h1>New</h1>
      </div>
    )
  }
}
