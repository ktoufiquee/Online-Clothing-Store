import React, { Component } from 'react';

export default class Single extends Component {
  render() {
    return (
      <div>
        <h1>Single</h1>
      </div>
    )
  }
}
