import React, { Component } from 'react';

export default class List extends Component {
  render() {
    return (
      <div>
        <h1>List</h1>
      </div>
    )
  }
}


